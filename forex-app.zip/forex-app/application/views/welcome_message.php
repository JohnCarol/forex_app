<html lang="en">
<head>
	<title>Forex Buyer</title>
	<!-- Fonts -->
	<!--<link href='//fonts.googleapis.com/css?family=Roboto:400,300' rel='stylesheet' type='text/css'>-->
	<link rel="stylesheet" href="app/css/bootstrap.min.css">
	<script src="app/jquery.min.js"></script>
	<script src="app/bootstrap.min.js"></script>
	<!-- Angular JS -->
	<script src="app/angular.min.js"></script>  
	<script src="app/angular-route.min.js"></script>

	<script src="app/angular-resource.min.js"></script>
	<!-- MY App -->
	
	<script src="app/routes.js"></script>
	<script src="app/services/myServices.js"></script>
	<script src="app/helper/myHelper.js"></script>
	<!-- App Controller -->
	<script src="app/controllers/ItemController.js"></script>
</head>
<body ng-app="forexApp">
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<div class="navbar-header">
				
				<a class="navbar-brand" href="#">Forex buyer</a>
			</div>
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav">
					<li><a href="#/">Home</a></li>
					<li><a href="#/items">Orders</a></li>
				</ul>
			</div>
		</div>
	</nav>
	
		<ng-view></ng-view>
	
</body>
</html>