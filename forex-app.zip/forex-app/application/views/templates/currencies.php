<div ng-controller="currController">    
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h1>Currencies - Last updated {{last_updated}}</h1>
            </div>
        </div>
    </div>
    <table>
        <thead>
            <tr>
                <th>Currency</th>
                <th>Rate</th>
            </tr>
        </thead>
        <tbody>
            <tr ng-repeat = "value in currencies">
                <td>--{{ value.currency_name }} ({{value.curr_shrt}})</td>
                <td>--{{ value.rate }}</td>
            </tr>
        </tbody>
    </table>
</div>