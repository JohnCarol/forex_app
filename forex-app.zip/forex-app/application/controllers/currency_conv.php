<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Currency_conv extends CI_Controller {
	public function index()
	{
		
		$this->load->database();
		
		$query = $this->db->get('v_curr_summary');
		$data['currencies'] = $query->result();		
		//echo json_encode($data);

		$query = $this->db->get('orders');
		$data['orders'] = $query->result();		
		echo json_encode($data);
	}

	public function update_curr()
	{
		$data = file_get_contents(
    	'http://jsonrates.com/get/?'.
    	'from=ZAR'.
    	'&to=USD'
		);
		$json = json_decode($data);
		$USDrate = (float) $json->rate;

		$data = file_get_contents(
    	'http://jsonrates.com/get/?'.
    	'from=ZAR'.
    	'&to=GBP'
		);
		$json = json_decode($data);
		$GBPrate = (float) $json->rate;

		$data = file_get_contents(
    	'http://jsonrates.com/get/?'.
    	'from=ZAR'.
    	'&to=KES'
		);
		$json = json_decode($data);
		$USDrate = (float) $json->rate;

		$data = file_get_contents(
    	'http://jsonrates.com/get/?'.
    	'from=ZAR'.
    	'&to=EUR'
		);
		$json = json_decode($data);
		$EURrate = (float) $json->rate;

		$last_update = time(); 






	}
	public function saveorder()
    {
    	
    	$this->load->database();
    	$_POST = json_decode(file_get_contents('php://input'), true);    
    	//echo "-->".print_r($_POST);	
    	$insert = $this->input->post();
		$this->db->insert('orders', $insert);
		$id = $this->db->insert_id();
		$q = $this->db->get_where('orders', array('id' => $id));
		echo json_encode($q->row());
    }
    public function sendemail()
    {
    	;

    	    $this->load->library('email');

    	    $order = json_decode(file_get_contents('php://input'), true);

    	    $curr = $order['curr'];
    	    $rate = $order['rate'];
    	    $amt_purch = number_format($order['amt_purchased'],2);
    	    $amt_paid = $order['amt_paid'];
    	    $discount = $order['discount'];
    	    $order_date = date('d-m-Y');
    	    $total_paid = number_format($amt_paid, 2);
    	    $discounted_amt = 0;
    	    if($discount != $amt_paid)
    	    	{

    	    		$discounted_amt = $amt_paid - $discount;
    	    		$total_paid = number_format($discounted_amt,2);
    	    		 
    	    	}

    	    $message = "Thank you for your order!<br><br>";
    	    $message.= "Order date: $order_date <br>";
    	    $message.= "Foreign currency bought: $curr <br>";
    	    $message.= "Exchange rate: $rate <br>";
    	    $message.= "Amount purchased: $amt_purch <br>";
    	    $message.= "Discounted amount: $discounted_amt <br>";
    	    $message.= "<br><br><strong>Total paid: $total_paid</strong><br><br>";
    	    $message.= "Thank you for your business.<br> The Forex Buyer Team.";

            $config['protocol']='smtp';
            $config['smtp_host']='ssl://smtp.gmail.com';
            $config['smtp_port']='465';
            $config['smtp_timeout']='30';
            $config['smtp_user']='';
            $config['smtp_pass']='';
            $config['charset']='utf-8';
            $config['newline']="\r\n";
            $config['wordwrap'] = TRUE;
            $config['mailtype'] = 'html';
            $this->email->initialize($config);
            $this->email->from('', 'Forex Buyer');
            $this->email->to('');
            $this->email->subject('Notification Mail: Your order was processed.');
            $this->email->message($message);
            

	 	
    	if(!$this->email->send()) {
        $data = array('success' => false, 'message' => 'Message could not be sent. Mailer Error: '.$this->email->print_debugger());
        echo json_encode($data);
        exit;

        $data = array('success' => true, 'message' => 'Message sent successfuly.');
    	echo json_encode($data);

    }


    	
    }
}
?>