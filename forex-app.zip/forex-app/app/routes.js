var app =  angular.module('forexApp',['ngRoute']);
app.config(['$routeProvider',
    function($routeProvider) {
        $routeProvider.
            when('/', {
                templateUrl: 'index.php/templates/currencies.html',
                controller: 'currController'
            }).
            when('/orders', {
                templateUrl: 'templates/orders.html',
                controller: 'currController'
            });
}]);