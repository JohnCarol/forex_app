app.controller('currController', function(dataFactory,$scope, $http) {
  $scope.data = [];
  $scope.message = '';
  

  dataFactory.httpRequest("index.php/currency_conv/index")
  .then(function (response) {$scope.currencies = response.currencies, $scope.orders = response.orders;});

$scope.saveOrder = function(type){

	//dataFactory.httpRequest('index.php/currency_conv/saveorder','POST',{},$scope.form).then(function(data) {

  

  discount = $scope.currency.discount;
  discount_amt = 0;

  surcharge_perc = $scope.currency.surcharge;
  $scope.curr.rate = $scope.currency.rate;
  $scope.curr.surcharge = surcharge_perc;

  if(type == 'zar')
  {
  	amount = $scope.curr.amt_paid;
  	calc = amount * $scope.curr.rate;
  	surcharge_amt = (surcharge_perc * calc)/100;
  	$scope.curr.amt_purchased = calc - surcharge_amt ;
  	//alert(amount);

  }
  else
  {
  	amt_purchased = $scope.curr.amt_purchased;
  	calc = amt_purchased/$scope.curr.rate;
  	surcharge_amt = (surcharge_perc * calc)/100;
  	amount = calc + surcharge_amt;  	
  }
  
  $scope.curr.amt_paid = amount;
  //alert($scope.curr.amt_paid);
  $scope.curr.curr = $scope.currency.curr_shrt;		
  
  $scope.curr.action_id = $scope.currency.action_code_id;
  action = $scope.currency.action;
  
  
  $scope.curr.amt_surcharge = surcharge_amt;
  $scope.curr.amt_less_surcharge = $scope.curr.amt_paid - surcharge_amt;
  discount_amt = amount - (amount * discount/100);
  
  $scope.curr.discount = discount_amt;

   		
  		if(action == 'Email')
  		{
  			//alert($scope);
  			dataFactory.httpRequest('index.php/currency_conv/sendemail','POST',{},$scope.curr).then(function(data) {
  			
  			});
  		}

  			
  		//$scope.message = 'Your order was saved successfully';
      
  

	


  dataFactory.httpRequest('index.php/currency_conv/saveorder','POST',{},$scope.curr).then(function(data) {
      $scope.orders.push(data);
      $scope.message = 'Your order was saved successfully';
      if(action == '1'){
      	$scope.message = 'Your order was emailed successfully';
      }
      $(".modal").modal("hide");


    });
  }

});




